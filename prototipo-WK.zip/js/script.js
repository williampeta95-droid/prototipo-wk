document.addEventListener('DOMContentLoaded', function(){
    console.log("Prototipo W&K cargado correctamente");
    const secciones=document.querySelectorAll('section');
    secciones.forEach(sec=>{sec.addEventListener('click',()=>{
        alert(`Has hecho clic en la sección: ${sec.querySelector('h2').innerText}`);
    });});
});
